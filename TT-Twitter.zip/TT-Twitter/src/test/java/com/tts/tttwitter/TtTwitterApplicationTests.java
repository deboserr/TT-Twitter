package com.tts.tttwitter;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TtTwitterApplicationTests {

	@Test
	void contextLoads() {
	}

}
